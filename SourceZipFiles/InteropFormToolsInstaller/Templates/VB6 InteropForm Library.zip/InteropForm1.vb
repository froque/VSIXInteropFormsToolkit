Imports Microsoft.InteropFormTools

<InteropForm()> _
Public Class InteropForm1

End Class