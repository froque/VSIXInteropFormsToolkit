Imports Microsoft.InteropFormTools

<InteropForm()> _
Public Class $safeitemname$

End Class